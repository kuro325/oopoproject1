package test;
import javax.swing.*;
import java.awt.*;
import javax.swing.border.LineBorder;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class RegisterFrame extends JFrame {
    
    // Method to validate if string contains only letters and spaces
    private boolean isValidName(String name) {
        if (name == null || name.trim().isEmpty()) {
            return false;
        }
        // Regular expression to allow only letters, spaces, hyphens, and apostrophes
        // This handles names like "John Doe", "Mary-Anne", "O'Connor"
        return name.matches("^[a-zA-Z\\s\\-']+$");
    }
    
    // Method to validate email format
    private boolean isValidEmail(String email) {
        if (email == null || email.trim().isEmpty()) {
            return false;
        }
        // Basic email validation
        return email.matches("^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$");
    }
    
    // Method to validate password strength
    private boolean isValidPassword(String password) {
        if (password == null || password.length() < 6) {
            return false;
        }
        return true;
    }
    
    // Method to validate employer ID (alphanumeric only)
    private boolean isValidEmployerId(String id) {
        if (id == null || id.trim().isEmpty()) {
            return true; // Optional field, can be empty
        }
        return id.matches("^[a-zA-Z0-9]+$");
    }
    
    // Method to validate department (letters and spaces only)
    private boolean isValidDepartment(String dept) {
        if (dept == null || dept.trim().isEmpty()) {
            return true; // Optional field, can be empty
        }
        return dept.matches("^[a-zA-Z\\s]+$");
    }
    
    // Method to validate vehicle number (alphanumeric only)
    private boolean isValidVehicleNumber(String vehicle) {
        if (vehicle == null || vehicle.trim().isEmpty()) {
            return true; // Optional field, can be empty
        }
        return vehicle.matches("^[a-zA-Z0-9]+$");
    }
    
    public RegisterFrame() {
        setTitle("E-Parking System - Register");
        setSize(1000,700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridBagLayout());

        JPanel main_panel = new JPanel();
        main_panel.setBackground(Color.WHITE);
        main_panel.setBorder(new LineBorder(Color.GRAY));
        main_panel.setPreferredSize(new Dimension(450,550));
        main_panel.setLayout(new BorderLayout());

        JPanel header_panel = new JPanel(new GridLayout(2,1));
        header_panel.setBackground(new Color(0,166,62));
        header_panel.setPreferredSize(new Dimension(400,80));

        JLabel header_title = new JLabel("E-Parking System", SwingConstants.CENTER);
        header_title.setForeground(Color.WHITE);
        header_title.setFont(new Font("SansSerif",Font.BOLD,30));

        JLabel header_title_2 = new JLabel("Create an Account", SwingConstants.CENTER);
        header_title_2.setForeground(Color.WHITE);
        header_title_2.setFont(new Font("SansSerif",Font.PLAIN,16));

        header_panel.add(header_title);
        header_panel.add(header_title_2);

        JPanel main_body = new JPanel();
        main_body.setBackground(Color.WHITE);
        main_body.setLayout(new BoxLayout(main_body, BoxLayout.Y_AXIS));
        main_body.setBorder(BorderFactory.createEmptyBorder(30,30,30,30));

        JPanel type_panel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        type_panel.setBackground(Color.WHITE);

        JLabel type_label = new JLabel("Account Type:");
        String[] accountTypes = {"Employee", "Admin"};
        JComboBox<String> type_dropdown = new JComboBox<>(accountTypes);
        type_dropdown.setPreferredSize(new Dimension(200,30));

        type_panel.add(type_label);
        type_panel.add(type_dropdown);
        
        main_body.add(type_panel);
        
        JPanel row1 = new JPanel(new GridLayout(1,2,20,0));
        row1.setBackground(Color.WHITE);

        JPanel name_panel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        name_panel.setBackground(Color.WHITE);
        JLabel name_label = new JLabel("Full Name:");
        JTextField name_field = new JTextField(15);
        name_panel.add(name_label);
        name_panel.add(name_field);

        JPanel email_panel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        email_panel.setBackground(Color.WHITE);
        JLabel email_label = new JLabel("Email:");
        JTextField email_field = new JTextField(15);
        email_panel.add(email_label);
        email_panel.add(email_field);

        row1.add(name_panel);
        row1.add(email_panel);

        JPanel row2 = new JPanel(new GridLayout(1,2,20,0));
        row2.setBackground(Color.WHITE);

        JPanel pass_panel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        pass_panel.setBackground(Color.WHITE);
        JLabel pass_label = new JLabel("Password:");
        JPasswordField pass_field = new JPasswordField(15);
        pass_panel.add(pass_label);
        pass_panel.add(pass_field);

        JPanel confirm_panel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        confirm_panel.setBackground(Color.WHITE);
        JLabel confirm_label = new JLabel("Confirm Password:");
        JPasswordField confirm_field = new JPasswordField(15);
        confirm_panel.add(confirm_label);
        confirm_panel.add(confirm_field);

        row2.add(pass_panel);
        row2.add(confirm_panel);

        JPanel row3 = new JPanel(new GridLayout(1,2,20,0));
        row3.setBackground(Color.WHITE);

        JPanel id_panel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        id_panel.setBackground(Color.WHITE);
        JLabel id_label = new JLabel("Employer ID:");
        JTextField id_field = new JTextField(15);
        id_panel.add(id_label);
        id_panel.add(id_field);

        JPanel dept_panel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        dept_panel.setBackground(Color.WHITE);
        JLabel dept_label = new JLabel("Department:");
        JTextField dept_field = new JTextField(15);
        dept_panel.add(dept_label);
        dept_panel.add(dept_field);

        row3.add(id_panel);
        row3.add(dept_panel);

        JPanel vehicle_panel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        vehicle_panel.setBackground(Color.WHITE);
        JLabel vehicle_label = new JLabel("Vehicle Number:");
        JTextField vehicle_field = new JTextField(15);
        vehicle_panel.add(vehicle_label);
        vehicle_panel.add(vehicle_field);

        JPanel terms_panel = new JPanel();
        terms_panel.setBackground(Color.WHITE);
        terms_panel.setLayout(new BoxLayout(terms_panel, BoxLayout.X_AXIS));
        JCheckBox terms_checkbox = new JCheckBox("I agree to the Terms and Conditions");
        terms_checkbox.setBackground(Color.WHITE);
        terms_checkbox.setAlignmentX(Component.CENTER_ALIGNMENT);
        terms_panel.add(Box.createHorizontalGlue());
        terms_panel.add(terms_checkbox);
        terms_panel.add(Box.createHorizontalGlue());

        JPanel button_panel = new JPanel();
        button_panel.setBackground(Color.WHITE);
        JButton registerBtn = new JButton("Create Account");
        registerBtn.setBackground(new Color(0,166,62));
        registerBtn.setForeground(Color.WHITE);
        registerBtn.setPreferredSize(new Dimension(250,40));

        JLabel login_label = new JLabel("Already Have An Account? Login here");
        login_label.setForeground(new Color(0,166,62));
        login_label.setCursor(new Cursor(Cursor.HAND_CURSOR));
        login_label.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        login_label.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                new LoginFrame().setVisible(true);
                dispose();
            }
        });

        button_panel.add(registerBtn);
        button_panel.add(Box.createVerticalStrut(10));
        button_panel.add(login_label);

        main_body.add(row1);
        main_body.add(Box.createVerticalStrut(15));
        main_body.add(row2);
        main_body.add(Box.createVerticalStrut(15));
        main_body.add(row3);
        main_body.add(Box.createVerticalStrut(30)); 
        main_body.add(vehicle_panel);
        main_body.add(Box.createVerticalStrut(20));
        main_body.add(terms_panel);
        main_body.add(Box.createVerticalStrut(25));
        main_body.add(button_panel);

        main_panel.add(header_panel, BorderLayout.NORTH);
        main_panel.add(main_body, BorderLayout.CENTER);
        add(main_panel);

        registerBtn.addActionListener(e -> {
            String accountType = type_dropdown.getSelectedItem().toString();
            String name = name_field.getText();
            String email = email_field.getText();
            String password = new String(pass_field.getPassword());
            String confirmPass = new String(confirm_field.getPassword());
            String employerId = id_field.getText();
            String department = dept_field.getText();
            String vehicle = vehicle_field.getText();

            // Validation checks
            if(!terms_checkbox.isSelected()) {
                JOptionPane.showMessageDialog(this, "Please agree to the Terms and Conditions", "Validation Error", JOptionPane.WARNING_MESSAGE);
                return;
            }

            if(!isValidName(name)) {
                JOptionPane.showMessageDialog(this, "Full Name can only contain letters, spaces, hyphens, and apostrophes!\nExample: John Doe, Mary-Anne, O'Connor", "Validation Error", JOptionPane.WARNING_MESSAGE);
                name_field.requestFocus();
                return;
            }
            
            if(!isValidEmail(email)) {
                JOptionPane.showMessageDialog(this, "Please enter a valid email address!\nExample: user@domain.com", "Validation Error", JOptionPane.WARNING_MESSAGE);
                email_field.requestFocus();
                return;
            }
            
            if(!isValidPassword(password)) {
                JOptionPane.showMessageDialog(this, "Password must be at least 6 characters long!", "Validation Error", JOptionPane.WARNING_MESSAGE);
                pass_field.requestFocus();
                return;
            }
            
            if(!password.equals(confirmPass)) {
                JOptionPane.showMessageDialog(this, "Passwords do not match!", "Validation Error", JOptionPane.WARNING_MESSAGE);
                confirm_field.requestFocus();
                return;
            }
            
            if(!isValidEmployerId(employerId)) {
                JOptionPane.showMessageDialog(this, "Employer ID can only contain letters and numbers!", "Validation Error", JOptionPane.WARNING_MESSAGE);
                id_field.requestFocus();
                return;
            }
            
            if(!isValidDepartment(department)) {
                JOptionPane.showMessageDialog(this, "Department can only contain letters and spaces!", "Validation Error", JOptionPane.WARNING_MESSAGE);
                dept_field.requestFocus();
                return;
            }
            
            if(!isValidVehicleNumber(vehicle)) {
                JOptionPane.showMessageDialog(this, "Vehicle Number can only contain letters and numbers!\nExample: ABC123", "Validation Error", JOptionPane.WARNING_MESSAGE);
                vehicle_field.requestFocus();
                return;
            }

            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                
                Connection con = DriverManager.getConnection(
                        "jdbc:mysql://localhost:3306/e_parking", "root", ""
                );

                String sql = "INSERT INTO users(account_type, full_name, email, password, employer_id, department, vehicle_number) VALUES (?,?,?,?,?,?,?)";
                PreparedStatement pst = con.prepareStatement(sql);
                pst.setString(1, accountType);
                pst.setString(2, name);
                pst.setString(3, email);
                pst.setString(4, password); 
                pst.setString(5, employerId);
                pst.setString(6, department);
                pst.setString(7, vehicle);

                pst.executeUpdate();
                JOptionPane.showMessageDialog(this,"Account Created Successfully!");
                con.close(); 
                
                // Optionally redirect to login after successful registration
                new LoginFrame().setVisible(true);
                dispose();

            } catch (ClassNotFoundException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this,"MySQL Driver not found!");
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this,"Database Error: " + ex.getMessage());
            }
        });

        setVisible(true);
    }
}